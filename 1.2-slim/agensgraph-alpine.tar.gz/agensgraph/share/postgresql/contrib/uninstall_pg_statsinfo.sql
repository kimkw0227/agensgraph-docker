/*
 * lib/uninstall_pg_statsinfo.sql
 *
 * Copyright (c) 2009-2017, NIPPON TELEGRAPH AND TELEPHONE CORPORATION
 */

DROP SCHEMA IF EXISTS statsinfo CASCADE;
